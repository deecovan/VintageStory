# RecipeSelector

Allows you to choose a specific recipe if they conflict

https://mods.vintagestory.at/recipeselector
