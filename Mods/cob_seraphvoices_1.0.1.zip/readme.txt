============================================================================
Provided by "CONQUEST OF BLOCKS" - Multiplayer server for Vintage Story.
============================================================================

This small mod will replace the vanilla seraph voices (instrumental sounds) with, well... my own. Sort of.
~ WickedSchnitzel


Server Website: www.vintagestory.online
Server Discord: discord.gg/jbVQTd3h77